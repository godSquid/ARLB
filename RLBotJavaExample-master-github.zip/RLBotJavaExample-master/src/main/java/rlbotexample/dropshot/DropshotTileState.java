package rlbotexample.dropshot;

public enum DropshotTileState {
    UNKNOWN,
    FRESH,
    DAMAGED,
    DESTROYED
}
