package rlbotexample;

import rlbot.Bot;
import rlbot.ControllerState;
import rlbot.cppinterop.RLBotDll;
import rlbot.flat.GameTickPacket;
import rlbot.flat.QuickChatSelection;
import rlbot.manager.BotLoopRenderer;
import rlbot.render.Renderer;
import rlbotexample.boost.BoostManager;
import rlbotexample.dropshot.DropshotTile;
import rlbotexample.dropshot.DropshotTileManager;
import rlbotexample.dropshot.DropshotTileState;
import rlbotexample.input.CarData;
import rlbotexample.input.DataPacket;
import rlbotexample.output.ControlsOutput;
import rlbotexample.vector.Vector2;
import rlbotexample.skills.TimedAction;
import rlbotexample.intercept.BallPath;
import rlbotexample.intercept.Intercept;
import rlbotexample.intercept.InterceptCalculator;
import rlbotexample.skills.DribbleMode;
import rlbotexample.plan.Plan;
import rlbotexample.skills.Volley;
import rlbotexample.vector.Vector3;

import java.io.IOException;
import java.awt.*;
import java.util.ArrayList;

public class SampleBot implements Bot {

    private final int playerIndex;
    private final int VOLLEY_HEIGHT = 0;
    private Plan plan;
    Vector2 myGoal = new Vector2(0,0);
    Vector2 oppGoal= new Vector2(0, 0);

    Vector2 BLBoost;
    Vector2 BRBoost;
    Vector2 MLBoost;
    Vector2 MRBoost;
    Vector2 FLBoost;
    Vector2 FRBoost;

    public SampleBot(int playerIndex) {
        this.playerIndex = playerIndex;
    }
    int temp =1;
    int control = 0;


    /**
     * This is where we keep the actual bot logic. This function shows how to chase the ball.
     * Modify it to make your bot smarter!
     */
    private ControlsOutput processInput(DataPacket input) /*throws Exception*/ {

        Vector2 ballPosition = input.ball.position.flatten();
        CarData myCar = input.car;
        Vector2 carPosition = myCar.position.flatten();
        Vector2 carDirection = myCar.orientation.noseVector.flatten();

        Vector2 midline = new Vector2(0, 0);
        Boolean offenseCar;
        Boolean offenseBall;

        int random_bias = (int) Math.random() * 100;   //random bias for moves
        int Yaw = 0;
        int Pitch = 0;
        int Drive = 0;

        int next_direction = 0;


        //set constant values
        if (input.team == 0) {   //blue team goal locations
            Vector2 myGoal = new Vector2(0, -5120);
            Vector2 oppGoal = new Vector2(0, 5120);

            //checks field positiion
            if (carPosition.y < midline.y) {
                offenseCar = false;
            } else {
                offenseCar = true;
            }

            if (ballPosition.y < midline.y) {
                offenseBall = false;
            } else {
                offenseBall = true;
            }

            //blue boost locations
            Vector2 BLBoost = new Vector2(3072.0, -4096.0);
            Vector2 BRBoost = new Vector2(-3072.0, -4096.0);
            Vector2 MLBoost = new Vector2(3584.0, 0.0);
            Vector2 MRBoost = new Vector2(-3584.0, 0.0);
            Vector2 FLBoost = new Vector2(3072.0, 4096.0);
            Vector2 FRBoost = new Vector2(-3072.0, 4096.0);
        } else {                  //orange team goal locations
            Vector2 myGoal = new Vector2(0, 5120);
            Vector2 oppGoal = new Vector2(0, -5120);

            //is car on offfesive half
            if (carPosition.y > midline.y) {
                offenseCar = false;
            } else {
                offenseCar = true;
            }
            //is ball on offensice half
            if (ballPosition.y > midline.y) {
                offenseBall = false;
            } else {
                offenseBall = true;
            }

            //Orange Boost Locations
            Vector2 FRBoost = new Vector2(3072.0, -4096.0);
            Vector2 FLBoost = new Vector2(-3072.0, -4096.0);
            Vector2 MRBoost = new Vector2(3584.0, 0.0);
            Vector2 MLBoost = new Vector2(-3584.0, 0.0);
            Vector2 BRBoost = new Vector2(3072.0, 4096.0);
            Vector2 BLBoost = new Vector2(-3072.0, 4096.0);
        }

        //create to goal vector
        Vector2 toGoal = oppGoal.minus(carPosition);
        //defending goal
        Vector2 defend = myGoal.minus(carPosition);

        // Subtract the two positions to get a vector pointing from the car to the ball.
        Vector2 carToBall = ballPosition.minus(carPosition);

        // How far does the car need to rotate before it's pointing exactly at the ball?
        double steerCorrectionRadians = carDirection.correctionAngle(carToBall);

        boolean goLeft = steerCorrectionRadians > 0;

        //finds direction needed to get nearest boost
        Vector2 carToBoost = getBoost(myCar);
        // double boostSteerCorrectionRadius = carDirection.correctionAngle(carToBoost);
        //boolean goLeftToBoost = boostSteerCorrectionRadius > 0;
        //check if boost is under a certain level && ball is certain distance away -> get closest

        //find direction needed to go back to defense
        Vector2 carToDefense = myGoal.minus(carPosition);
        //     double defenseSteerCorrectionRadius = carDirection.correctionAngle(carToDefense);
        //       boolean goLeftToDefense = defenseSteerCorrectionRadius > 0;

        //direction to enemy goal, need for dribbles and shooting
        Vector2 carToOffense = oppGoal.minus(carPosition);
        double offenseSteerCorectionRadius = carDirection.correctionAngle(carToOffense);
        boolean goLeftToOffense = offenseSteerCorectionRadius > 0;

        Vector3 centerField = new Vector3(0, 0, 0);
       // if (input.ball.position.flatten() == centerField.flatten()) {
        //    getPlan(0, myCar, input, false);
      //  }

        //ball and car are on defense
       // if ((offenseCar != true) && (offenseBall != true)) {
            //check bias/ random value
            //if((bias > 10)&&(random < 50){
            //checks to volley the ball

            try {
                BallPath ballPath = new BallPath(RLBotDll.getBallPrediction());

                if (input.ball.position.z > VOLLEY_HEIGHT) {
                    Intercept volleyPoint = InterceptCalculator.getVolleyPoint(ballPath, input.car, VOLLEY_HEIGHT);

                    if (volleyPoint != null) {
                        //renderer.drawString2d("Volley available!", Color.white, new Point(10, 200), 2, 2);

                        plan = new Plan().withStep(new Volley());
                        return plan.getOutput(input, this);
                    }

                }
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            //}
            //}
            //else {
            //if(myCar.boost<12){
            //  plan = getPlan(,myCar,input,goLeft);//boost plan
            //          }
            //  }
        }

        if((offenseCar == true) && (offenseBall != true))
        {
                //return to net plan
                //plan = getPlan(1,myCar,input,defendsGoLeft);
        }
        //if((offenseCar == true) && (offenseBall == true))
       // {
            try {
                BallPath ballPath = new BallPath(RLBotDll.getBallPrediction());

                if (input.ball.position.z > VOLLEY_HEIGHT) {
                    Intercept volleyPoint = InterceptCalculator.getVolleyPoint(ballPath, input.car, VOLLEY_HEIGHT);

                    if (volleyPoint != null) {
                        //renderer.drawString2d("Volley available!", Color.white, new Point(10, 200), 2, 2);

                        plan = new Plan().withStep(new Volley());
                        return plan.getOutput(input, this);
                    }

                }
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
       // }
        if((offenseCar != true) && (offenseBall == true))
        {
            //boost plan
            //plan = getPlan(1,myCar,input,boostGoLeft);
            //if(planDone(plan,input,this))
            //{
                //plan = getPlan(1, input, goLeftToOffense);
            //}
        }


        // This is optional!
        drawDebugLines(input, myCar, goLeft);

        // This is also optional!
        if (input.ball.position.z > 300) {
            RLBotDll.sendQuickChat(playerIndex, false, QuickChatSelection.Compliments_NiceOne);
        }

        if (plan != null) {
            ControlsOutput planOutput = plan.getOutput(input, this);
            if (planOutput == null) {
                plan = null;
            } else {
                return planOutput;
            }
        }

        Plan x = getPlan(control, myCar, input, goLeft);
        /*plan = new Plan()
                .withStep(new TimedAction(.4, new ControlsOutput().withThrottle(1).withBoost().withSteer(goLeft ? -1 : 1)))
                .withStep(new TimedAction(.02, new ControlsOutput()))
                .withStep(new TimedAction(0.2,new ControlsOutput().withJump()))
                .withStep(new TimedAction(.05,new ControlsOutput()))
                .withStep(new TimedAction(0.05, new ControlsOutput().withJump().withPitch(-1)));
*/
       //if(planDone(plan,input,this) == true)
    //   {
      //     plan = getPlan(control,myCar,input,goLeft);
    //   }

        try {
            BallPath ballPath = new BallPath(RLBotDll.getBallPrediction());

            if (input.ball.position.z > VOLLEY_HEIGHT) {
                Intercept volleyPoint = InterceptCalculator.getVolleyPoint(ballPath, input.car, VOLLEY_HEIGHT);

                if (volleyPoint != null) {
                    //renderer.drawString2d("Volley available!", Color.white, new Point(10, 200), 2, 2);

                    plan = new Plan().withStep(new Volley());
                    return plan.getOutput(input, this);
                }

            }
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }

        //output plan

        plan = getPlan(9,myCar,input,goLeftToOffense);
        return plan.getOutput(input, this);

          // return new ControlsOutput();
          //      .withSteer(goLeft ? -1 : 1)
          //      .withThrottle(1);*/
    }

    //override method - resets the plan to base and then then reruns getPlan - should be called from AI section/main
    public void override(DataPacket input, CarData car)
    {
            plan = new Plan().withStep(new TimedAction(.02, new ControlsOutput()));
    }

    public Plan getPlan(int control, CarData car, DataPacket input, boolean goLeft)
    {
        switch(control) {
            case 0:
                plan = new Plan()
                        .withStep(new TimedAction(0.01, new ControlsOutput().withThrottle(1).withBoost().withSteer(goLeft ? -1 : 1)))
                        .withStep(new TimedAction(0.01, new ControlsOutput().withThrottle(1).withBoost().withSteer(goLeft ? -1 : 1)))
                        .withStep(new TimedAction(0.01, new ControlsOutput().withThrottle(1).withBoost().withSteer(goLeft ? -1 : 1)))
                        .withStep(new TimedAction(0.01, new ControlsOutput().withThrottle(1).withBoost().withSteer(goLeft ? -1 : 1)))
                        .withStep(new TimedAction(0.2,new ControlsOutput().withJump()))
                        .withStep(new TimedAction(.05,new ControlsOutput()))
                        .withStep(new TimedAction(0.05, new ControlsOutput().withJump().withPitch(-1)));
                return plan;
            case 1:
                //drive plan
                plan = new Plan()
                        .withStep(new TimedAction(0.05,new ControlsOutput().withThrottle(1)));
                return plan;
            case 2:
                //steering plan
                plan = new Plan()
                        .withStep(new TimedAction(0.05,new ControlsOutput().withThrottle(1).withSteer(goLeft ? -1 : 1)));
                return plan;
            case 3:
                //backflip plan
                plan= new Plan()
                        .withStep(new TimedAction(0.05,new ControlsOutput().withJump()))
                        .withStep(new TimedAction(0.05, new ControlsOutput()))
                        .withStep(new TimedAction(0.05, new ControlsOutput().withJump().withPitch(1)));
                return plan;
            case 4:
                //frontflip plan
                Plan frontFlip = new Plan()
                        .withStep(new TimedAction(0.05,new ControlsOutput().withJump()))
                        .withStep(new TimedAction(0.05, new ControlsOutput()))
                        .withStep(new TimedAction(0.05, new ControlsOutput().withJump().withPitch(-1)));
                return frontFlip;
            case 5:
                Plan startFly = new Plan();
                if(input.car.hasWheelContact) {
                    //fly plan
                   startFly= new Plan()
                            .withStep(new TimedAction(0.05, new ControlsOutput().withJump()))
                            .withStep(new TimedAction(0.05, new ControlsOutput().withPitch(1)))
                            .withStep(new TimedAction(0.05, new ControlsOutput().withPitch(1)))
                            .withStep(new TimedAction(0.05, new ControlsOutput().withPitch(1)))
                            .withStep(new TimedAction(0.05, new ControlsOutput().withPitch(1)))
                            .withStep(new TimedAction(0.05, new ControlsOutput()));
                }
                else {
                        startFly = new Plan()
                            .withStep(new TimedAction(0.05, new ControlsOutput().withPitch(0)))
                            .withStep(new TimedAction(0.05, new ControlsOutput().withBoost()))
                            .withStep(new TimedAction(0.05, new ControlsOutput().withBoost()))
                            .withStep(new TimedAction(0.05, new ControlsOutput().withBoost()))
                            .withStep(new TimedAction(0.05, new ControlsOutput().withBoost()))
                            .withStep(new TimedAction(0.05, new ControlsOutput().withBoost()));
                    }
                        return startFly;
            case 6:
                //flip right
                plan = new Plan()
                        .withStep(new TimedAction(0.05,new ControlsOutput().withJump()))
                        .withStep(new TimedAction(0.05, new ControlsOutput()))
                        .withStep(new TimedAction(0.05, new ControlsOutput().withJump().withYaw(1)));
                return plan;
            case 7:
                //flip left
                plan  = new Plan()
                        .withStep(new TimedAction(0.05,new ControlsOutput().withJump()))
                        .withStep(new TimedAction(0.05, new ControlsOutput()))
                        .withStep(new TimedAction(0.05, new ControlsOutput().withJump().withYaw(-1)));
                return plan;
            case 8:
                plan = new Plan()
                        .withStep(new TimedAction(0.02, new ControlsOutput().withSteer(goLeft ? -1 : 1).withThrottle(1)))
                        .withStep(new TimedAction(0.02, new ControlsOutput().withSteer(goLeft ? -1 : 1).withThrottle(1)))
                        .withStep(new TimedAction(0.02, new ControlsOutput().withSteer(goLeft ? -1 : 1).withThrottle(1)));
                return plan;
            case 9:
                plan = new Plan()
                        .withStep(new TimedAction(0.02, new ControlsOutput().withSteer(goLeft ? -1 : 1).withThrottle(1)))
                        .withStep(new TimedAction(0.02, new ControlsOutput().withSteer(goLeft ? -1 : 1).withThrottle(1)))
                        .withStep(new TimedAction(0.02, new ControlsOutput().withSteer(goLeft ? -1 : 1).withThrottle(1)));
                return plan;

                default:
                    plan = new Plan();
        }
        return plan;
    }

    //finds the closest boost
    public Vector2 getBoost(CarData car)
    {
        Vector2 closestBoost=BRBoost;

        ArrayList<Vector2> boostDistence = new ArrayList<Vector2>();
        //double[] boostDistence = new double[6];
      //  boostDistence.add( car.position.flatten().minus(BRBoost));
      //  boostDistence.add(car.position.flatten().minus(BLBoost));
      //  boostDistence.add(car.position.flatten().minus(MRBoost));
      //  boostDistence.add(car.position.flatten().minus(MLBoost));
      //  boostDistence.add(car.position.flatten().minus(FLBoost));
      //  boostDistence.add(car.position.flatten().minus(FRBoost));


         for(int i = 0; i < boostDistence.size(); i++)
        {
            for (int j = i + 1; j < boostDistence.size(); j++)
            {
                if (boostDistence.get(i).magnitude() > boostDistence.get(j).magnitude())
                {
                    closestBoost =  boostDistence.get(i);
                    boostDistence.set(i,boostDistence.get(j));
                    boostDistence.set(j,closestBoost);
                }
            }
        }
         return closestBoost;
    }

    public Boolean planDone(Plan input, DataPacket dataPacket, Bot bot)
    {
        if (input.getOutput(dataPacket,bot)== null)
        {
            //plan is complete
            return true;
        }
        else {
            //plan is incomplete
            return false;
        }
    }

    public Vector2 findClosestBoost(CarData myCar)
    {
        int length;
        Vector2 x = myCar.position.flatten().minus(BLBoost);
        return x.scaled(1);
    }
    /**
     * This is a nice example of using the rendering feature.
     */
    private void drawDebugLines(DataPacket input, CarData myCar, boolean goLeft) {
        // Here's an example of rendering debug data on the screen.
        Renderer renderer = BotLoopRenderer.forBotLoop(this);

        // Draw a line from the car to the ball
        renderer.drawLine3d(Color.LIGHT_GRAY, myCar.position, input.ball.position);

        //renderer.drawLine2d(Color.CYAN, myCar.position, (0,-5120,0));

        // Draw a line that points out from the nose of the car.
        renderer.drawLine3d(goLeft ? Color.BLUE : Color.RED,
                myCar.position.plus(myCar.orientation.noseVector.scaled(150)),
                myCar.position.plus(myCar.orientation.noseVector.scaled(300)));

        renderer.drawString3d(goLeft ? "left" : "right", Color.WHITE, myCar.position, 2, 2);

        for (DropshotTile tile: DropshotTileManager.getTiles()) {
            if (tile.getState() == DropshotTileState.DAMAGED) {
                renderer.drawCenteredRectangle3d(Color.YELLOW, tile.getLocation(), 4, 4, true);
            } else if (tile.getState() == DropshotTileState.DESTROYED) {
                renderer.drawCenteredRectangle3d(Color.RED, tile.getLocation(), 4, 4, true);
            }
        }

        // Draw a rectangle on the tile that the car is on
        DropshotTile tile = DropshotTileManager.pointToTile(myCar.position.flatten());
        if (tile != null) renderer.drawCenteredRectangle3d(Color.green, tile.getLocation(), 8, 8, false);
    }


    @Override
    public int getIndex() {
        return this.playerIndex;
    }

    /**
     * This is the most important function. It will automatically get called by the framework with fresh data
     * every frame. Respond with appropriate controls!
     */
    @Override
    public ControllerState processInput(GameTickPacket packet)  {

        if (packet.playersLength() <= playerIndex || packet.ball() == null || !packet.gameInfo().isRoundActive()) {
            // Just return immediately if something looks wrong with the data. This helps us avoid stack traces.
            return new ControlsOutput();
        }

        // Update the boost manager and tile manager with the latest data
        BoostManager.loadGameTickPacket(packet);
        DropshotTileManager.loadGameTickPacket(packet);

        // Translate the raw packet data (which is in an unpleasant format) into our custom DataPacket class.
        // The DataPacket might not include everything from GameTickPacket, so improve it if you need to!
        DataPacket dataPacket = new DataPacket(packet, playerIndex);

        // Do the actual logic using our dataPacket.
        ControlsOutput controlsOutput = processInput(dataPacket);

        return controlsOutput;
    }

    public void retire() {
        System.out.println("Retiring sample bot " + playerIndex);
    }
}
